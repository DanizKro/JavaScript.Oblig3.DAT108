package com.oblig3_DAT108.Oblig;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Oblig3Dat108Application {

	public static void main(String[] args) {
		SpringApplication.run(Oblig3Dat108Application.class, args);
	}

}
