package com.oblig3_DAT108.Oblig;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Oblig3Dat108ApplicationTests {

	@Test
	void contextLoads() {
	}

}
